'use client';

import { useState } from 'react';
import { FIREResult, ComparisonSummary } from '@/lib/calculations';
import { countries } from '@/data/countries';
import { formatCurrency, formatPercent, smartCurrency } from '@/lib/formatters';
import { convertCurrency } from '@/lib/currency';
import { CostOfLivingCard } from './CostOfLivingCard';
import MoveToCountryPanel from './MoveToCountryPanel';
import { MonteCarloCard } from './MonteCarloCard';
import { ReverseCalculator } from './ReverseCalculator';
import { TaxBreakdownCard } from './TaxBreakdownCard';
import { CoastFIRECard } from './CoastFIRECard';
import { UserInputs } from '@/lib/calculations';
import HealthcareAffiliate from './HealthcareAffiliate';
import { JourneyTimeline } from './JourneyTimeline';
import { AnimatedNumber } from './AnimatedNumber';

interface ResultsPanelProps {
  result1: FIREResult;
  result2: FIREResult;
  comparison: ComparisonSummary;
  country1Code: string;
  country2Code: string;
  annualSpending?: number;
  spendingCurrency?: string;
  userAge?: number;
  inputs?: UserInputs;
  expectedReturn?: number;
  inflationRate?: number;
  simplifiedMode?: boolean;
}

export function ResultsPanel({ 
  result1, 
  result2, 
  comparison, 
  country1Code, 
  country2Code,
  annualSpending = 50000,
  spendingCurrency = 'USD',
  userAge = 35,
  inputs,
  expectedReturn,
  inflationRate,
  simplifiedMode = false
}: ResultsPanelProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showTaxNotes, setShowTaxNotes] = useState(false);
  const country1 = countries[country1Code];
  const country2 = countries[country2Code];
  const isSameCountry = country1Code === country2Code;

  // Determine winner info for Summary
  const getWinnerInfo = () => {
    if (isSameCountry) return null;
    
    const targetAge = inputs?.targetRetirementAge || 50;
    const country1HitsTarget = result1.fireAge <= targetAge;
    const country2HitsTarget = result2.fireAge <= targetAge;
    const bothMissTarget = !country1HitsTarget && !country2HitsTarget;
    const yearsBehind1 = result1.fireAge - targetAge;
    const yearsBehind2 = result2.fireAge - targetAge;
    
    if (bothMissTarget) {
      const bestOption = result1.fireAge <= result2.fireAge ? country1Code : country2Code;
      const bestYearsBehind = Math.min(yearsBehind1, yearsBehind2);
      return {
        type: 'warning' as const,
        message: `Neither option reaches your target age of ${targetAge}. ${countries[bestOption]?.name} is closest (${bestYearsBehind} yr${bestYearsBehind > 1 ? 's' : ''} later).`
      };
    }
    
    // Calculate earliest possible FIRE age for each country
    const findEarliestFI = (result: FIREResult) => {
      const earliest = result.projections?.find(p => (p.liquidEnd || 0) >= result.fireNumber * 0.95);
      return earliest?.age || result.fireAge;
    };
    const earliest1 = findEarliestFI(result1);
    const earliest2 = findEarliestFI(result2);
    
    const yearsDiff = Math.abs(result1.yearsUntilFIRE - result2.yearsUntilFIRE);
    const earliestDiff = Math.abs(earliest1 - earliest2);
    
    // Determine winner using earliest possible FIRE age (the real comparison)
    const winner = earliestDiff >= 1
      ? (earliest1 <= earliest2 ? country1Code : country2Code)
      : comparison.lowerFIRENumber;  // If same earliest age, lower FIRE number wins
    
    // Build message using earliest ages
    let message: string;
    if (earliestDiff >= 2) {
      const earlierAge = Math.min(earliest1, earliest2);
      message = `Reach FI at age ${earlierAge} — ${earliestDiff} yr${earliestDiff > 1 ? 's' : ''} earlier than ${countries[earliest1 <= earliest2 ? country2Code : country1Code]?.name}`;
    } else if (earliestDiff >= 1) {
      message = `Reach FI ${earliestDiff} year earlier`;
    } else {
      message = `Similar timeline — ${formatCurrency(comparison.fireNumberDifferenceUSD, 'USD')} lower FIRE number`;
    }
    
    return {
      type: 'success' as const,
      winner: countries[winner]?.name,
      winnerCode: winner,
      message,
      yearsDiff,
    };
  };

  const winnerInfo = getWinnerInfo();

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg sm:text-xl font-semibold text-gray-900 dark:text-white">FIRE Comparison</h2>
        <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
          <span className="text-blue-600 dark:text-blue-400">{country1?.flag} {country1?.name}</span>
          {!isSameCountry && (
            <> vs <span className="text-emerald-600 dark:text-emerald-400">{country2?.flag} {country2?.name}</span></>
          )}
        </p>
      </div>

      {/* SUMMARY - Now at the TOP */}
      {!isSameCountry && winnerInfo && (
        <div className={`rounded-xl p-4 animate-scale-in ${
          winnerInfo.type === 'success' 
            ? 'bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 border border-green-300 dark:border-green-600' 
            : 'bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/30 dark:to-orange-900/30 border border-amber-300 dark:border-amber-600'
        }`}>
          <div className="flex items-start gap-3">
            <span className="text-2xl">{winnerInfo.type === 'success' ? '✦' : '⚠️'}</span>
            <div className="flex-1">
              <h3 className={`font-bold text-base sm:text-lg ${
                winnerInfo.type === 'success' 
                  ? 'text-green-700 dark:text-green-300' 
                  : 'text-amber-700 dark:text-amber-300'
              }`}>
                {winnerInfo.type === 'success' ? `${winnerInfo.winner} is more favorable` : 'Similar outcome'}
              </h3>
              <p className={`text-sm mt-0.5 ${
                winnerInfo.type === 'success' 
                  ? 'text-green-600 dark:text-green-400' 
                  : 'text-amber-600 dark:text-amber-400'
              }`}>
                {winnerInfo.message}
              </p>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-1"></span>
                  <span className="text-gray-600 dark:text-gray-400 break-words">
                    FIRE # {formatCurrency(comparison.fireNumberDifferenceUSD, 'USD')} {comparison.lowerFIRENumber === country1Code ? 'lower in ' + country1?.name : 'lower in ' + country2?.name}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0 mt-1"></span>
                  <span className="text-gray-600 dark:text-gray-400 break-words">
                    Tax {formatPercent(comparison.taxRateDifference)} {comparison.lowerEffectiveTaxRate === country1Code ? 'lower in ' + country1?.name : 'lower in ' + country2?.name}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Country Cards - Stack on mobile, side-by-side on tablet+ */}
      {/* Winner card shows first on mobile for immediate impact */}
      {(() => {
        const country2IsWinner = !isSameCountry && winnerInfo?.type === 'success' && winnerInfo?.winnerCode === country2Code;
        
        const card1 = (
          <CountryCard 
            result={result1} 
            country={country1} 
            isLowerFIRE={comparison.lowerFIRENumber === country1Code}
            isLowerTax={comparison.lowerEffectiveTaxRate === country1Code}
            isSoonerRetirement={
              result1.yearsUntilFIRE === result2.yearsUntilFIRE
                ? comparison.lowerFIRENumber === country1Code
                : comparison.earlierRetirement === country1Code
            }
            otherCountryCode={country2Code}
            portfolioValue={inputs?.portfolioValue}
            portfolioCurrency={inputs?.portfolioCurrency}
            targetRetirementAge={inputs?.targetRetirementAge}
            currentAge={inputs?.currentAge}
            colorScheme={country2IsWinner ? "green" : "blue"}
            isWinner={winnerInfo?.type === 'success' && winnerInfo?.winnerCode === country1Code}
          />
        );
        
        const card2 = !isSameCountry ? (
          <CountryCard 
            result={result2} 
            country={country2}
            isLowerFIRE={comparison.lowerFIRENumber === country2Code}
            isLowerTax={comparison.lowerEffectiveTaxRate === country2Code}
            isSoonerRetirement={
              result1.yearsUntilFIRE === result2.yearsUntilFIRE
                ? comparison.lowerFIRENumber === country2Code
                : comparison.earlierRetirement === country2Code
            }
            otherCountryCode={country1Code}
            portfolioValue={inputs?.portfolioValue}
            portfolioCurrency={inputs?.portfolioCurrency}
            targetRetirementAge={inputs?.targetRetirementAge}
            currentAge={inputs?.currentAge}
            colorScheme={country2IsWinner ? "blue" : "green"}
            hideAffiliate={simplifiedMode}
            isWinner={winnerInfo?.type === 'success' && winnerInfo?.winnerCode === country2Code}
          />
        ) : null;

        return (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {country2IsWinner ? card2 : card1}
            {country2IsWinner ? card1 : card2}
          </div>
        );
      })()}

      {/* 🔥 FIRE Journey Chart - Moved up for maximum visibility */}
      <JourneyTimeline
        projections1={result1.projections}
        projections2={isSameCountry ? undefined : (() => {
          // Normalize country2 projections to country1's currency for chart comparison
          const c1Currency = country1?.currency || 'USD';
          const c2Currency = country2?.currency || 'USD';
          if (c1Currency === c2Currency) return result2.projections;
          return result2.projections.map(p => ({
            ...p,
            portfolioEnd: convertCurrency(p.portfolioEnd, c2Currency, c1Currency),
            portfolioStart: convertCurrency(p.portfolioStart, c2Currency, c1Currency),
            liquidEnd: convertCurrency(p.liquidEnd, c2Currency, c1Currency),
            liquidStart: convertCurrency(p.liquidStart, c2Currency, c1Currency),
            illiquidEnd: convertCurrency(p.illiquidEnd || 0, c2Currency, c1Currency),
            illiquidStart: convertCurrency(p.illiquidStart || 0, c2Currency, c1Currency),
            growth: convertCurrency(p.growth, c2Currency, c1Currency),
            withdrawal: convertCurrency(p.withdrawal, c2Currency, c1Currency),
            savings: convertCurrency(p.savings, c2Currency, c1Currency),
          }));
        })()}
        country1Code={country1Code}
        country2Code={isSameCountry ? undefined : country2Code}
        retirementAge={inputs?.targetRetirementAge || 50}
        expectedReturn={expectedReturn}
        inflationRate={inflationRate}
      />

      {/* CoastFIRE Insight */}
      {inputs && (
        <div className={`grid ${isSameCountry ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'} gap-3`}>
          <CoastFIRECard
            result={result1}
            inputs={inputs}
            countryCode={country1Code}
            label={isSameCountry ? undefined : country1?.name}
          />
          {!isSameCountry && (
            <CoastFIRECard
              result={result2}
              inputs={inputs}
              countryCode={country2Code}
              label={country2?.name}
            />
          )}
        </div>
      )}

      {/* If You Retired Today */}
      {!simplifiedMode && inputs && (
        <ReverseCalculator
          portfolioValue={inputs.portfolioValue}
          portfolioCurrency={inputs.portfolioCurrency}
          country1Code={country1Code}
          country2Code={country2Code}
          currentSpending={inputs.annualSpending}
          safeWithdrawalRate={inputs.safeWithdrawalRate}
          usState={inputs.usState}
        />
      )}

      {/* Cost of Living Comparison */}
      {!isSameCountry && (
        <CostOfLivingCard
          fromCountry={country1Code}
          toCountry={country2Code}
          annualSpending={annualSpending}
          spendingCurrency={spendingCurrency}
        />
      )}

      {/* Warnings - shown near financial analysis for context */}
      <Warnings result1={result1} result2={result2} country1={country1} country2={country2} isSameCountry={isSameCountry} />

      {/* Tax Notes */}
      {!simplifiedMode && <CollapsibleTaxNotes result1={result1} result2={result2} country1={country1} country2={country2} isSameCountry={isSameCountry} showTaxNotes={showTaxNotes} setShowTaxNotes={setShowTaxNotes} />}

      {/* Advanced Analysis - Monte Carlo + Tax Breakdown */}
      {!simplifiedMode && inputs && (
        <div className="border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full p-4 flex items-center justify-between text-left bg-gray-50 dark:bg-slate-800/50 hover:bg-gray-100 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">📊</span>
              <div>
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Advanced Analysis</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">Monte Carlo simulations, tax breakdowns, and more</p>
              </div>
            </div>
            <svg 
              className={`w-5 h-5 text-gray-400 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {showAdvanced && (
            <div className="p-4 space-y-4 border-t border-gray-200 dark:border-slate-700">
              {/* Monte Carlo Analysis */}
              <div className="space-y-3">
                <MonteCarloCard
                  inputs={inputs}
                  fireResult={result1}
                  countryCode={country1Code}
                />
                {!isSameCountry && (
                  <MonteCarloCard
                    inputs={inputs}
                    fireResult={result2}
                    countryCode={country2Code}
                  />
                )}
              </div>

              {/* Tax Breakdown Details */}
              <div className="space-y-3">
                <TaxBreakdownCard
                  grossIncome={result1.annualWithdrawalGross}
                  countryCode={country1Code}
                  incomeType="mixed"
                  userCurrency={inputs?.portfolioCurrency || 'USD'}
                />
                {!isSameCountry && (
                  <TaxBreakdownCard
                    grossIncome={result2.annualWithdrawalGross}
                    countryCode={country2Code}
                    incomeType="mixed"
                    userCurrency={inputs?.portfolioCurrency || 'USD'}
                  />
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Plan Your Move - Visa, checklist & tools (action planning last) */}
      {!simplifiedMode && !isSameCountry && (
        <MoveToCountryPanel
          countryCode={country2Code}
          userAge={userAge}
          fromCurrency={country1?.currency || 'USD'}
          toCurrency={country2?.currency || 'EUR'}
          showDifferentCurrencies={country1?.currency !== country2?.currency}
        />
      )}

    </div>
  );
}

function CountryCard({ 
  result, 
  country, 
  isLowerFIRE,
  isLowerTax,
  isSoonerRetirement,
  otherCountryCode,
  portfolioValue,
  portfolioCurrency,
  targetRetirementAge,
  currentAge,
  colorScheme = 'blue',
  hideAffiliate = false,
  isWinner: isWinnerProp = false
}: { 
  result: FIREResult; 
  country: typeof countries[string];
  isLowerFIRE: boolean;
  isLowerTax: boolean;
  isSoonerRetirement: boolean;
  otherCountryCode: string;
  portfolioValue?: number;
  portfolioCurrency?: string;
  targetRetirementAge?: number;
  currentAge?: number;
  colorScheme?: 'blue' | 'green';
  hideAffiliate?: boolean;
  isWinner?: boolean;
}) {
  const canFIRE = result.canRetire;
  
  // Check if already financially independent using LIQUID assets only
  // (Property is illiquid - can't withdraw from it annually)
  const liquidInFireCurrency = result.liquidPortfolioValue || 0;
  const alreadyFI = liquidInFireCurrency >= result.fireNumber;
  
  // Check if FIRE age is later than target
  const targetAge = targetRetirementAge || 50;
  const yearsLate = result.fireAge > targetAge ? result.fireAge - targetAge : 0;
  const hitsTarget = canFIRE && yearsLate === 0;
  const missesTarget = canFIRE && yearsLate > 0;
  
  // Determine card status - alreadyFI means hitsTarget
  const effectivelyOnTarget = hitsTarget || alreadyFI;
  const isWinner = isWinnerProp || (effectivelyOnTarget && isSoonerRetirement);
  const isOnTarget = effectivelyOnTarget && !isSoonerRetirement;
  const isBehindTarget = missesTarget && !alreadyFI;
  
  // Color bar based on scheme
  const colorBar = colorScheme === 'blue' 
    ? 'bg-blue-500' 
    : 'bg-emerald-500';
  
  // Card styling based on status - clean card with left accent border
  const cardStyles = isWinner
    ? 'bg-white dark:bg-slate-800 border-2 border-green-400 dark:border-green-500'
    : isOnTarget
    ? 'bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 border-l-4 border-l-green-500'
    : isBehindTarget
    ? 'bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 border-l-4 border-l-amber-500'
    : 'bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 border-l-4 border-l-red-500';
  
  const badgeStyles = isWinner
    ? 'bg-green-500 text-white'
    : isOnTarget
    ? 'bg-green-500 text-white'
    : isBehindTarget
    ? 'bg-amber-500 text-white'
    : 'bg-red-500 text-white';
  
  const badgeText = alreadyFI
    ? '✓ Already FI'
    : isWinner 
    ? '✓ More favorable' 
    : isOnTarget 
    ? '✓ On track'
    : isBehindTarget
    ? `${yearsLate} yr${yearsLate > 1 ? 's' : ''} later`
    : '✗ Shortfall';

  return (
    <div className={`relative rounded-xl p-3 sm:p-4 ${cardStyles}`}>
      {/* Header with Badge */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-1.5">
          <span className="text-base sm:text-lg">{country?.flag}</span>
          <h3 className="text-xs sm:text-sm font-semibold text-gray-900 dark:text-white truncate">{country?.name}</h3>
        </div>
        <span className={`text-[10px] sm:text-xs px-1.5 py-0.5 rounded font-medium whitespace-nowrap ${badgeStyles}`}>
          {badgeText}
        </span>
      </div>

      <div className="space-y-3">
        {/* FIRE Number */}
        <div>
          <span className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400">FIRE Number</span>
          {(() => {
            const localCurrency = country?.currency || 'USD';
            const userCurrency = portfolioCurrency || 'USD';
            // Show in user's currency when local currency would produce huge numbers (VND, IDR, KRW, COP, etc.)
            const showInUserCurrency = localCurrency !== userCurrency && result.fireNumber > 10_000_000;
            const displayValue = showInUserCurrency 
              ? convertCurrency(result.fireNumber, localCurrency, userCurrency)
              : result.fireNumber;
            const displayCurrency = showInUserCurrency ? userCurrency : localCurrency;
            
            return (
              <>
                <p className="text-lg sm:text-2xl font-bold text-gray-900 dark:text-white">
                  <AnimatedNumber 
                    value={displayValue} 
                    formatter={(n) => formatCurrency(Math.round(n), displayCurrency)} 
                  />
                </p>
                {showInUserCurrency && (
                  <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    ≈ {formatCurrency(Math.round(result.fireNumber), localCurrency)} local
                  </p>
                )}
              </>
            );
          })()}
        </div>

        {/* Portfolio Breakdown - show if there's illiquid (property) */}
        {result.illiquidPortfolioValue > 0 && (() => {
          const localCurrency = country?.currency || 'USD';
          const userCurrency = portfolioCurrency || 'USD';
          const showInUser = localCurrency !== userCurrency && result.liquidPortfolioValue > 10_000_000;
          const dispCurr = showInUser ? userCurrency : localCurrency;
          const liq = showInUser ? convertCurrency(result.liquidPortfolioValue, localCurrency, userCurrency) : result.liquidPortfolioValue;
          const illiq = showInUser ? convertCurrency(result.illiquidPortfolioValue, localCurrency, userCurrency) : result.illiquidPortfolioValue;
          return (
          <div className="bg-white/50 dark:bg-slate-800/50 rounded-lg p-2 -mx-1">
            <span className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400">Your Portfolio</span>
            <div className="flex items-center justify-between mt-1">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-gray-900 dark:text-white">
                  {formatCurrency(liq, dispCurr)}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Liquid (withdrawable)</p>
              </div>
              <div className="text-right">
                <p className="text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-400">
                  {formatCurrency(illiq, dispCurr)}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Property (illiquid)</p>
              </div>
            </div>
            <p className="text-[10px] text-amber-600 dark:text-amber-400 mt-1">
              ⚠️ Withdrawals only come from liquid assets
            </p>
          </div>
          );
        })()}

        {/* Years to FIRE */}
        <div>
          <span className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400">Years to FIRE</span>
          {(() => {
            // Calculate earliest possible FIRE age from projections
            const earliestFI = result.projections?.find(p => {
              const liquidAtAge = p.liquidEnd || 0;
              return liquidAtAge >= result.fireNumber * 0.95;
            });
            const earliestAge = alreadyFI ? (currentAge || 35) : earliestFI?.age;
            const targetAge2 = targetRetirementAge || 50;
            const couldRetireEarlier = earliestAge !== undefined && earliestAge < targetAge2 - 1;
            const earliestYears = earliestAge !== undefined ? Math.max(0, earliestAge - (currentAge || 35)) : null;
            
            // Show the earliest realistic number, not the artificial target
            const displayYears = couldRetireEarlier ? earliestYears! : result.yearsUntilFIRE;
            const displayAge = couldRetireEarlier ? earliestAge! : result.fireAge;
            
            return (
              <>
                <p className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white">
                  {alreadyFI ? (
                    <span className="text-green-600 dark:text-green-400">0 years</span>
                  ) : canFIRE ? (
                    <span className={couldRetireEarlier ? 'text-green-600 dark:text-green-400' : ''}>
                      {displayYears} year{displayYears === 1 ? '' : 's'}
                    </span>
                  ) : (
                    <span className="text-red-600 dark:text-red-400">Cannot retire</span>
                  )}
                </p>
                {alreadyFI ? (
                  <p className="text-[10px] sm:text-xs text-green-600 dark:text-green-400 mt-0.5">
                    ✓ Liquid assets exceed FIRE number - ready now!
                  </p>
                ) : couldRetireEarlier ? (
                  <p className="text-[10px] sm:text-xs text-green-600 dark:text-green-400 mt-0.5">
                    🚀 Age {displayAge} — {targetAge2 - displayAge}yr ahead of your target!
                  </p>
                ) : canFIRE && (
                  <p className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                    {yearsLate === 0 ? (
                      <span className="text-green-600 dark:text-green-400">✓ Age {result.fireAge} (on target)</span>
                    ) : (
                      <span className="text-amber-600 dark:text-amber-400">Age {result.fireAge} ({yearsLate}yr late)</span>
                    )}
                  </p>
                )}
              </>
            );
          })()}
        </div>

        {/* Tax Rate */}
        <div>
          <span className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400">Effective Tax Rate</span>
          <p className="text-sm sm:text-base font-medium text-gray-900 dark:text-white">
            {formatPercent(result.effectiveTaxRate)}
          </p>
          <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5 break-words">
          {(() => {
            const localCurrency = country?.currency || 'USD';
            const userCurrency = portfolioCurrency || 'USD';
            const showInUser = localCurrency !== userCurrency && result.annualWithdrawalGross > 10_000_000;
            const dispCurr = showInUser ? userCurrency : localCurrency;
            const gross = showInUser ? convertCurrency(result.annualWithdrawalGross, localCurrency, userCurrency) : result.annualWithdrawalGross;
            const net = showInUser ? convertCurrency(result.annualWithdrawalNet, localCurrency, userCurrency) : result.annualWithdrawalNet;
            return `Gross ${formatCurrency(gross, dispCurr)} → Net ${formatCurrency(net, dispCurr)}`;
          })()}
          </p>
        </div>

        {/* Healthcare */}
        <div>
          <span className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400">Healthcare</span>
          <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300">
            {(() => {
              const cost = country?.healthcare?.estimatedAnnualCostPreRetirement || 500;
              const s = smartCurrency(cost, country?.currency || 'USD', portfolioCurrency || 'USD');
              const formatted = formatCurrency(s.amount, s.currency);
              return cost > 5000 ? (
                <span className="text-amber-600 dark:text-amber-400">~{formatted}/yr</span>
              ) : (
                <span className="text-green-600 dark:text-green-400">✓ Public + ~{formatted}/yr</span>
              );
            })()}
          </p>
          {country?.healthcare?.notes && (
            <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5 line-clamp-2">
              {country.healthcare.notes}
            </p>
          )}
          {/* Expat Health Insurance Affiliate */}
          {colorScheme === 'green' && !hideAffiliate && (
            <HealthcareAffiliate
              retireCountryName={country?.name || ''}
              retireCountryCode={otherCountryCode}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function CollapsibleTaxNotes({ result1, result2, country1, country2, isSameCountry, showTaxNotes, setShowTaxNotes }: {
  result1: FIREResult;
  result2: FIREResult;
  country1: typeof countries[string];
  country2: typeof countries[string];
  isSameCountry: boolean;
  showTaxNotes: boolean;
  setShowTaxNotes: (v: boolean) => void;
}) {
  const allNotes = [...(result1.countrySpecificNotes || []), ...(!isSameCountry ? (result2.countrySpecificNotes || []) : [])];
  
  if (allNotes.length === 0) return null;

  return (
    <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl overflow-hidden">
      <button
        onClick={() => setShowTaxNotes(!showTaxNotes)}
        className="w-full p-3 sm:p-4 flex items-center justify-between text-left hover:bg-amber-100/50 dark:hover:bg-amber-800/20 transition-colors"
      >
        <h3 className="text-sm font-semibold text-amber-800 dark:text-amber-200 flex items-center gap-2">
          ⚠️ Important Tax Considerations
          <span className="text-[10px] font-normal text-amber-600 dark:text-amber-400">({allNotes.length} note{allNotes.length > 1 ? 's' : ''})</span>
        </h3>
        <svg 
          className={`w-5 h-5 text-amber-500 transition-transform ${showTaxNotes ? 'rotate-180' : ''}`} 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {showTaxNotes && (
        <div className="px-3 pb-3 sm:px-4 sm:pb-4">
          <ul className="space-y-1.5">
            {allNotes.map((note, i) => (
              <li key={i} className="text-xs text-amber-700 dark:text-amber-300 flex items-start gap-2">
                <span className="text-amber-500 mt-0.5">•</span>
                <span>{note}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function Warnings({ result1, result2, country1, country2, isSameCountry }: {
  result1: FIREResult;
  result2: FIREResult;
  country1: typeof countries[string];
  country2: typeof countries[string];
  isSameCountry: boolean;
}) {
  const allWarnings = [...(result1.warnings || []), ...(!isSameCountry ? (result2.warnings || []) : [])];
  
  if (allWarnings.length === 0) return null;

  return (
    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-3 sm:p-4">
      <h3 className="text-sm font-semibold text-red-800 dark:text-red-200 mb-2 flex items-center gap-2">
        🚨 Warnings
      </h3>
      <ul className="space-y-1.5">
        {allWarnings.map((warning, i) => (
          <li key={i} className="text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
            <span className="text-red-500 mt-0.5">•</span>
            <span>{warning}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
