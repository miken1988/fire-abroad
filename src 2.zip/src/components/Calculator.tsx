'use client';

import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { UserInputs, compareFIRE } from '@/lib/calculations';
import { countries } from '@/data/countries';
import { InputPanel } from './InputPanel';
import { ResultsPanel } from './ResultsPanel';
import { fetchLiveRates, setRates, getDisplayRate, convertCurrency } from '@/lib/currency';
import { usStates } from '@/data/usStateTaxes';
import { decodeStateFromURL, encodeStateToURL, getShareableURL } from '@/lib/urlState';
import { PDFExportButton } from './PDFExport';
import { ThemeToggle } from './ThemeProvider';
import * as analytics from '@/lib/analytics';
import { formatCurrency, smartCurrency } from '@/lib/formatters';
import { ResultsSkeleton } from './ResultsSkeleton';

const defaultInputs: UserInputs = {
  currentAge: 35,
  targetRetirementAge: 50,
  currentCountry: 'US',
  targetCountry: 'PT',
  portfolioValue: 250000,
  portfolioCurrency: 'USD',
  portfolioAllocation: { stocks: 80, bonds: 15, cash: 5, crypto: 0, property: 0 },
  accounts: { taxDeferred: 100000, taxFree: 50000, taxable: 80000, crypto: 20000, cash: 0, property: 0, other: 0, otherLabel: '' },
  traditionalRetirementAccounts: 100000,
  rothAccounts: 50000,
  taxableAccounts: 80000,
  propertyEquity: 0,
  annualSpending: 50000,
  spendingCurrency: 'USD',
  annualSavings: 30000,
  expectStatePension: false,
  statePensionAmount: 22000,
  statePensionAge: 67,
  expectedReturn: 0.07,
  inflationRate: 0.03,
  safeWithdrawalRate: 0.04,
};

// What is FIRE explainer component
function WhatIsFIRE({ isOpen, onToggle }: { isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border border-amber-200 dark:border-amber-800 rounded-xl overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-amber-100/50 dark:hover:bg-amber-800/20 transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-xl">🔥</span>
          <span className="font-medium text-gray-900 dark:text-white">New to FIRE? Learn how this works</span>
        </div>
        <svg
          className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {isOpen && (
        <div className="px-4 pb-4 space-y-4 text-sm text-gray-700 dark:text-gray-300">
          <div className="grid sm:grid-cols-3 gap-4 pt-2">
            <div className="bg-white dark:bg-slate-800 rounded-lg p-3 shadow-sm">
              <div className="font-semibold text-gray-900 dark:text-white mb-1">💰 FIRE Number</div>
              <p className="text-xs">The total savings you need to retire. Calculated as your annual spending ÷ 4% (the "safe withdrawal rate").</p>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-lg p-3 shadow-sm">
              <div className="font-semibold text-gray-900 dark:text-white mb-1">📊 4% Rule</div>
              <p className="text-xs">Withdraw 4% of your portfolio yearly and historically it lasts 30+ years. We use this to calculate your FIRE number.</p>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-lg p-3 shadow-sm">
              <div className="font-semibold text-gray-900 dark:text-white mb-1">🌍 Why Compare?</div>
              <p className="text-xs">Different countries have different tax rates and living costs. You might retire years earlier abroad!</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 border-t border-amber-200 dark:border-amber-800 pt-3">
            <strong>Example:</strong> If you spend $40,000/year, your FIRE number is $1,000,000 ($40K ÷ 4%). But in Portugal with lower costs, you might only need $600,000!
          </p>
        </div>
      )}
    </div>
  );
}

// Simplified Quick Start inputs
function QuickStartInputs({ 
  inputs, 
  onChange,
  onShowAdvanced 
}: { 
  inputs: UserInputs; 
  onChange: (inputs: UserInputs) => void;
  onShowAdvanced: () => void;
}) {
  const countryOptions = Object.values(countries).map(c => ({
    value: c.code,
    label: `${c.flag} ${c.name}`,
  }));

  const handleChange = (field: keyof UserInputs, value: any) => {
    const newInputs = { ...inputs, [field]: value };
    if (field === 'currentCountry') {
      newInputs.portfolioCurrency = countries[value]?.currency || 'USD';
      newInputs.spendingCurrency = countries[value]?.currency || 'USD';
      analytics.trackCountrySelect('from', value, countries[value]?.name || value);
    }
    if (field === 'targetCountry') {
      analytics.trackCountrySelect('to', value, countries[value]?.name || value);
    }
    onChange(newInputs);
  };

  // Use refs to get values on blur instead of controlled inputs
  const currentAgeRef = React.useRef<HTMLInputElement>(null);
  const retirementAgeRef = React.useRef<HTMLInputElement>(null);
  const savingsRef = React.useRef<HTMLInputElement>(null);
  const spendingRef = React.useRef<HTMLInputElement>(null);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-4 sm:p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Quick Calculator</h2>
        <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-slate-700 px-2 py-1 rounded">Essential inputs only</span>
      </div>

      {/* Country Selection - Most Important */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">I currently live in</label>
          <select
            value={inputs.currentCountry}
            onChange={(e) => handleChange('currentCountry', e.target.value)}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          >
            {countryOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">I want to retire in</label>
          <select
            value={inputs.targetCountry}
            onChange={(e) => handleChange('targetCountry', e.target.value)}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          >
            {countryOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* US State - directly under country selectors */}
      {(inputs.currentCountry === 'US' || inputs.targetCountry === 'US') && (
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">US State (for state taxes)</label>
          <select
            value={inputs.usState || ''}
            onChange={(e) => handleChange('usState', e.target.value)}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          >
            <option value="">Select state...</option>
            {usStates.map(s => (
              <option key={s.code} value={s.code}>{s.name}</option>
            ))}
          </select>
        </div>
      )}

      {/* Age */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Current age</label>
          <input
            ref={currentAgeRef}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            defaultValue={inputs.currentAge}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              if (!isNaN(val) && val >= 1 && val <= 120) {
                handleChange('currentAge', val);
              }
            }}
            onBlur={(e) => {
              const val = parseInt(e.target.value);
              handleChange('currentAge', isNaN(val) || val < 1 ? 30 : val);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const val = parseInt((e.target as HTMLInputElement).value);
                handleChange('currentAge', isNaN(val) || val < 1 ? 30 : val);
                (e.target as HTMLInputElement).blur();
              }
            }}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Target retirement age</label>
          <input
            ref={retirementAgeRef}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            defaultValue={inputs.targetRetirementAge}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              if (!isNaN(val) && val >= 1 && val <= 120) {
                handleChange('targetRetirementAge', val);
              }
            }}
            onBlur={(e) => {
              const val = parseInt(e.target.value);
              handleChange('targetRetirementAge', isNaN(val) || val < 1 ? 50 : val);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const val = parseInt((e.target as HTMLInputElement).value);
                handleChange('targetRetirementAge', isNaN(val) || val < 1 ? 50 : val);
                (e.target as HTMLInputElement).blur();
              }
            }}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          />
        </div>
      </div>

      {/* Money */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
            Total savings
            <span className="text-gray-400 font-normal ml-1">({countries[inputs.currentCountry]?.currencySymbol})</span>
          </label>
          <input
            ref={savingsRef}
            type="text"
            inputMode="numeric"
            defaultValue={inputs.portfolioValue.toLocaleString()}
            onChange={(e) => {
              const val = parseFloat(e.target.value.replace(/,/g, ''));
              if (!isNaN(val) && val >= 0) {
                handleChange('portfolioValue', val);
              }
            }}
            onBlur={(e) => {
              const val = parseFloat(e.target.value.replace(/,/g, ''));
              handleChange('portfolioValue', isNaN(val) ? 0 : val);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const val = parseFloat((e.target as HTMLInputElement).value.replace(/,/g, ''));
                handleChange('portfolioValue', isNaN(val) ? 0 : val);
                (e.target as HTMLInputElement).blur();
              }
            }}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
            Annual spending
            <span className="text-gray-400 font-normal ml-1">({countries[inputs.currentCountry]?.currencySymbol})</span>
          </label>
          <input
            ref={spendingRef}
            type="text"
            inputMode="numeric"
            defaultValue={inputs.annualSpending.toLocaleString()}
            onChange={(e) => {
              const val = parseFloat(e.target.value.replace(/,/g, ''));
              if (!isNaN(val) && val >= 0) {
                handleChange('annualSpending', val);
              }
            }}
            onBlur={(e) => {
              const val = parseFloat(e.target.value.replace(/,/g, ''));
              handleChange('annualSpending', isNaN(val) ? 0 : val);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const val = parseFloat((e.target as HTMLInputElement).value.replace(/,/g, ''));
                handleChange('annualSpending', isNaN(val) ? 0 : val);
                (e.target as HTMLInputElement).blur();
              }
            }}
            className="w-full px-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-base sm:text-sm"
          />
        </div>
      </div>

      {/* Show Advanced Button */}
      <button
        onClick={onShowAdvanced}
        className="w-full py-2.5 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium flex items-center justify-center gap-2 border border-dashed border-gray-300 dark:border-slate-600 rounded-lg hover:border-blue-400 dark:hover:border-blue-500 transition-colors"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
        </svg>
        Customize account types, pensions, tax details...
      </button>
    </div>
  );
}

// Mobile sticky comparison header
function MobileStickyComparison({ 
  result1, 
  result2, 
  country1Code, 
  country2Code,
  isVisible 
}: { 
  result1: any; 
  result2: any; 
  country1Code: string; 
  country2Code: string;
  isVisible: boolean;
}) {
  const country1 = countries[country1Code];
  const country2 = countries[country2Code];
  const isSame = country1Code === country2Code;

  if (!isVisible || isSame) return null;

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700 shadow-lg z-50 px-4 py-3 safe-area-bottom">
      <div className="flex items-center justify-between gap-4">
        <div className="flex-1 text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">{country1?.flag} {country1?.name}</div>
          <div className="text-sm font-bold text-gray-900 dark:text-white">
            {formatCurrency(result1?.fireNumber || 0, country1?.currency || 'USD')}
          </div>
          <div className="text-xs text-gray-500">
            {result1?.canRetire ? `Age ${result1?.fireAge}` : 'Cannot FIRE'}
          </div>
        </div>
        <div className="text-gray-300 dark:text-gray-600">vs</div>
        <div className="flex-1 text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">{country2?.flag} {country2?.name}</div>
          <div className="text-sm font-bold text-gray-900 dark:text-white">
            {(() => {
              const c1Currency = country1?.currency || 'USD';
              const c2Currency = country2?.currency || 'USD';
              if (c1Currency === c2Currency) return formatCurrency(result2?.fireNumber || 0, c2Currency);
              const converted = convertCurrency(result2?.fireNumber || 0, c2Currency, c1Currency);
              return formatCurrency(converted, c1Currency);
            })()}
          </div>
          <div className="text-xs text-gray-500">
            {result2?.canRetire ? `Age ${result2?.fireAge}` : 'Cannot FIRE'}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Calculator() {
  const [inputs, setInputs] = useState<UserInputs>(defaultInputs);
  const [fxLoaded, setFxLoaded] = useState(false);
  const [fxError, setFxError] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const [activeTab, setActiveTabRaw] = useState<'inputs' | 'results'>('inputs');
  const setActiveTab = useCallback((tab: 'inputs' | 'results') => {
    setActiveTabRaw(tab);
    if (tab === 'results') analytics.trackResultsView();
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, []);
  const [showExplainer, setShowExplainer] = useState(true);
  const [advancedMode, setAdvancedModeRaw] = useState(false);
  const setAdvancedMode = useCallback((mode: boolean) => {
    setAdvancedModeRaw(mode);
    analytics.trackModeSwitch(mode ? 'advanced' : 'simplified');
  }, []);
  const [showMobileComparison, setShowMobileComparison] = useState(false);
  const prevResultsRef = useRef<string>('');

  // Swipe handling for mobile tabs
  const touchStartX = useRef(0);
  const touchStartY = useRef(0);
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  }, []);
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = e.changedTouches[0].clientY - touchStartY.current;
    // Only swipe if horizontal movement is dominant and > 80px
    if (Math.abs(dx) > 80 && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0 && activeTab === 'inputs') setActiveTab('results');
      if (dx > 0 && activeTab === 'results') setActiveTab('inputs');
    }
  }, [activeTab]);

  // Check if URL has params (returning user) - skip explainer and use advanced mode
  // Init engagement tracking
  useEffect(() => {
    analytics.trackEngagementTime();
    const cleanup = analytics.initScrollTracking();
    return cleanup;
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      if (searchParams.toString()) {
        const loadedInputs = decodeStateFromURL(searchParams, defaultInputs);
        setInputs(loadedInputs);
        setAdvancedMode(true); // Returning users get advanced mode
        setShowExplainer(false); // Returning users already know FIRE
      }
      setInitialized(true);
    }
  }, []);

  useEffect(() => {
    if (!initialized) return;
    const timeoutId = setTimeout(() => {
      const newParams = encodeStateToURL(inputs);
      const newURL = `${window.location.pathname}?${newParams}`;
      window.history.replaceState({}, '', newURL);
    }, 500);
    return () => clearTimeout(timeoutId);
  }, [inputs, initialized]);

  useEffect(() => {
    fetchLiveRates()
      .then((rates) => { setRates(rates); setFxLoaded(true); })
      .catch(() => { setFxError(true); setFxLoaded(true); });
  }, []);

  // Show mobile comparison bar when scrolled to results
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const handleScroll = () => {
      setShowMobileComparison(window.scrollY > 200);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [showShareMenu, setShowShareMenu] = useState(false);
  const shareMenuRef = useRef<HTMLDivElement>(null);

  // Close share menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (shareMenuRef.current && !shareMenuRef.current.contains(e.target as Node)) {
        setShowShareMenu(false);
      }
    };
    if (showShareMenu) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showShareMenu]);

  const results = useMemo(() => {
    try { return compareFIRE(inputs, inputs.currentCountry, inputs.targetCountry); }
    catch (error) { console.error('Calculation error:', error); return null; }
  }, [inputs, fxLoaded]);

  // Track calculation
  useEffect(() => {
    if (!results) return;
    analytics.trackCalculation({
      fromCountry: inputs.currentCountry,
      toCountry: inputs.targetCountry,
      portfolioValue: inputs.portfolioValue,
      annualSpending: inputs.annualSpending,
      currentAge: inputs.currentAge,
      retirementAge: inputs.targetRetirementAge,
      fireNumber1: results.country1.fireNumber,
      fireNumber2: results.country2.fireNumber,
      canRetire1: results.country1.canRetire,
      canRetire2: results.country2.canRetire,
      winner: results.comparison.earlierRetirement,
    });
    analytics.trackCalculationDepth();
  }, [inputs.currentCountry, inputs.targetCountry, inputs.portfolioValue, inputs.annualSpending]);

  const isSameCountry = inputs.currentCountry === inputs.targetCountry;
  const showFxRate = !isSameCountry && inputs.portfolioCurrency !== countries[inputs.targetCountry]?.currency;

  const getShareText = useCallback(() => {
    if (!results || isSameCountry) return 'Check out this FIRE calculator for retiring abroad!';
    const c1 = countries[inputs.currentCountry]?.name || '';
    const c2 = countries[inputs.targetCountry]?.name || '';
    const age1 = results.country1.fireAge;
    const age2 = results.country2.fireAge;
    if (age1 !== age2) {
      const better = age1 < age2 ? c1 : c2;
      const earlier = Math.min(age1, age2);
      return `I could reach FI at age ${earlier} in ${better}! Compare your early retirement across 24 countries:`;
    }
    return `Comparing early retirement in ${c1} vs ${c2}. Try it yourself:`;
  }, [results, isSameCountry, inputs.currentCountry, inputs.targetCountry]);

  const handleShare = useCallback(async (method: 'clipboard' | 'twitter' | 'linkedin' | 'native') => {
    const url = getShareableURL(inputs);
    const text = getShareText();
    analytics.trackShare(method);
    setShowShareMenu(false);

    if (method === 'native' && navigator.share) {
      try {
        await navigator.share({ title: 'Where To FIRE', text, url });
        return;
      } catch { /* user cancelled */ return; }
    }
    if (method === 'twitter') {
      window.open(`https://x.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
      return;
    }
    if (method === 'linkedin') {
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
      return;
    }
    // clipboard
    try {
      await navigator.clipboard.writeText(url);
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 3000);
    } catch { prompt('Copy this URL to share:', url); }
  }, [inputs, getShareText]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors pb-20 lg:pb-0">

      {/* Share Toast - More prominent */}
      {showShareToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-xl shadow-2xl z-[100] animate-fade-in flex items-center gap-3">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          <div>
            <div className="font-medium">Link copied!</div>
            <div className="text-xs text-green-100">Share this URL to show your exact scenario</div>
          </div>
        </div>
      )}

      <header className="border-b border-gray-200 dark:border-slate-700 sticky top-0 bg-white dark:bg-slate-900 z-40 transition-colors shadow-sm">
        <div className="max-w-7xl mx-auto px-3 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white truncate">
                <a href="/" className="hover:opacity-80 transition-opacity">Where to <span className="fire-gradient">FIRE</span></a>
              </h1>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 hidden sm:block">Compare early retirement across 24 countries · Real tax data · Free</p>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
              {showFxRate && fxLoaded && (
                <div className="hidden sm:block text-xs text-gray-500 dark:text-gray-400 border-r border-gray-200 dark:border-slate-700 pr-3">
                  💱 1 {inputs.portfolioCurrency} = {getDisplayRate(inputs.portfolioCurrency, countries[inputs.targetCountry]?.currency || 'USD')} {countries[inputs.targetCountry]?.currency}
                </div>
              )}
              {results && !isSameCountry && (
                <PDFExportButton
                  result1={results.country1}
                  result2={results.country2}
                  comparison={results.comparison}
                  country1Code={inputs.currentCountry}
                  country2Code={inputs.targetCountry}
                  inputs={inputs}
                />
              )}
              <div className="relative" ref={shareMenuRef}>
                <button 
                  onClick={() => setShowShareMenu(!showShareMenu)} 
                  className="flex items-center gap-1.5 px-3 py-2 sm:px-4 text-xs sm:text-sm bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg font-medium"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                  </svg>
                  <span>Share</span>
                </button>
                {showShareMenu && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-xl border border-gray-200 dark:border-slate-700 py-1 z-50 animate-fade-in">
                    <button onClick={() => handleShare('twitter')} className="w-full px-4 py-2.5 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-3">
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                      Post on X
                    </button>
                    <button onClick={() => handleShare('linkedin')} className="w-full px-4 py-2.5 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-3">
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                      Share on LinkedIn
                    </button>
                    <button onClick={() => handleShare('clipboard')} className="w-full px-4 py-2.5 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-3">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
                      Copy link
                    </button>
                  </div>
                )}
              </div>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Tab Navigation */}
      <div className="lg:hidden border-b border-gray-200 dark:border-slate-700 sticky top-[57px] bg-white dark:bg-slate-900 z-30 transition-colors">
        <div className="flex relative">
          <button onClick={() => setActiveTab('inputs')} className={`flex-1 py-3 text-sm font-medium text-center transition-colors ${activeTab === 'inputs' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
            📝 Your Details
          </button>
          <button onClick={() => setActiveTab('results')} className={`flex-1 py-3 text-sm font-medium text-center transition-colors ${activeTab === 'results' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
            📊 Results
          </button>
          {/* Animated underline indicator */}
          <div 
            className="absolute bottom-0 h-0.5 bg-blue-600 dark:bg-blue-400 transition-all duration-300 ease-out"
            style={{ 
              width: '50%', 
              left: activeTab === 'inputs' ? '0%' : '50%' 
            }}
          />
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-3 py-4 sm:px-6 sm:py-6 lg:px-8">
        {/* What is FIRE Explainer - Show for new users */}
        {!advancedMode && (
          <div className="mb-6">
            <WhatIsFIRE isOpen={showExplainer} onToggle={() => {
              const newState = !showExplainer;
              setShowExplainer(newState);
              if (newState) analytics.trackExplainerView();
            }} />
          </div>
        )}

        {/* Desktop Layout */}
        <div className="hidden lg:grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="lg:sticky lg:top-20 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto lg:scrollbar-thin">
            {/* Quick Start or Full Panel */}
            {!advancedMode ? (
              <QuickStartInputs 
                inputs={inputs} 
                onChange={setInputs} 
                onShowAdvanced={() => setAdvancedMode(true)} 
              />
            ) : (
              <div className="lg:border-r lg:pr-8 border-gray-200 dark:border-slate-700">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Your Details</h2>
                  <button 
                    onClick={() => setAdvancedMode(false)}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    ← Simplified view
                  </button>
                </div>
                <InputPanel inputs={inputs} onChange={setInputs} />
              </div>
            )}
            </div>
          </div>
          <div>
            {results ? (
              <div className="space-y-6">
                <ResultsPanel 
                  result1={results.country1} 
                  result2={results.country2} 
                  comparison={results.comparison} 
                  country1Code={inputs.currentCountry} 
                  country2Code={inputs.targetCountry} 
                  annualSpending={inputs.annualSpending} 
                  spendingCurrency={inputs.spendingCurrency} 
                  userAge={inputs.currentAge} 
                  inputs={inputs}
                  expectedReturn={inputs.expectedReturn}
                  inflationRate={inputs.inflationRate}
                  simplifiedMode={!advancedMode}
                />
              </div>
            ) : (
              <ResultsSkeleton />
            )}
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="lg:hidden" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
          {activeTab === 'inputs' && (
            <div className="space-y-6 animate-slide-in-left">
              {!advancedMode ? (
                <QuickStartInputs 
                  inputs={inputs} 
                  onChange={setInputs} 
                  onShowAdvanced={() => setAdvancedMode(true)} 
                />
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Your Details</h2>
                    <button 
                      onClick={() => setAdvancedMode(false)}
                      className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      ← Simplified view
                    </button>
                  </div>
                  <InputPanel inputs={inputs} onChange={setInputs} />
                </div>
              )}
              <button 
                onClick={() => setActiveTab('results')} 
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-medium hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg"
              >
                View Results →
              </button>
            </div>
          )}
          {activeTab === 'results' && results && (
            <div className="space-y-6 animate-slide-in-right">
              <ResultsPanel 
                result1={results.country1} 
                result2={results.country2} 
                comparison={results.comparison} 
                country1Code={inputs.currentCountry} 
                country2Code={inputs.targetCountry} 
                annualSpending={inputs.annualSpending} 
                spendingCurrency={inputs.spendingCurrency} 
                userAge={inputs.currentAge} 
                inputs={inputs}
                expectedReturn={inputs.expectedReturn}
                inflationRate={inputs.inflationRate}
                simplifiedMode={!advancedMode}
              />
            </div>
          )}
        </div>
      </main>

      {/* Mobile Sticky Comparison Bar */}
      {results && (
        <MobileStickyComparison
          result1={results.country1}
          result2={results.country2}
          country1Code={inputs.currentCountry}
          country2Code={inputs.targetCountry}
          isVisible={showMobileComparison && activeTab === 'results'}
        />
      )}
    </div>
  );
}
