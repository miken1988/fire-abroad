import { Calculator } from '@/components/Calculator';

export default function Home() {
  return <Calculator />;
}
